const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{"Content-Type":"application/json","Cache-Control":"no-store"}});
const allowed=new Set(["movie","drink","shopee"]);
export default async (req)=>{
 if(req.method!=="POST") return json({error:"Method not allowed"},405);
 try {
  const ip=req.headers.get("x-nf-client-connection-ip")||"unknown";
  // Simple honeypot is not exposed in the form; use platform/WAF rate limits for production.
  const body=await req.json();
  if(!allowed.has(body.service)) return json({error:"Dịch vụ không hợp lệ"},400);
  const fields={
   movie:["cinema","branch","movie","date","time","quantity","seats","notes"],
   drink:["brand","drinkDeal","drinkQty","budget","drinkNotes"],
   shopee:["productUrl","productName","variant","productQty","voucher","shopNotes"]
  }[body.service];
  const clean={}; for(const k of fields){const v=String(body[k]??"").trim();if(v.length>1500)return json({error:"Một trường thông tin quá dài"},400);clean[k]=v;}
  if(body.service==="shopee"&&clean.productUrl){let u;try{u=new URL(clean.productUrl)}catch{return json({error:"Link sản phẩm không hợp lệ"},400)}if(!["shopee.vn","www.shopee.vn"].includes(u.hostname))return json({error:"Chỉ chấp nhận link shopee.vn"},400);}
  const orderId="DD-"+crypto.randomUUID().slice(0,8).toUpperCase();
  const record={order_id:orderId,service:body.service,status:"new",details:clean,created_at:new Date().toISOString()};
  const {SUPABASE_URL,SUPABASE_SERVICE_ROLE_KEY,NOTIFY_WEBHOOK_URL}=process.env;
  if(!SUPABASE_URL||!SUPABASE_SERVICE_ROLE_KEY)return json({error:"Website chưa cấu hình cơ sở dữ liệu. Quản trị viên cần thiết lập Supabase trước khi nhận đơn."},503);
  const db=await fetch(`${SUPABASE_URL.replace(/\/$/,"")}/rest/v1/orders`,{method:"POST",headers:{"Content-Type":"application/json","apikey":SUPABASE_SERVICE_ROLE_KEY,"Authorization":`Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,"Prefer":"return=minimal"},body:JSON.stringify(record)});
  if(!db.ok){return json({error:"Không lưu được đơn hàng. Vui lòng thử lại sau."},502);}
  // Optional private automation webhook. Configure it to an approved Zalo OA/partner workflow.
  // Never put webhook secrets in frontend code.
  if(NOTIFY_WEBHOOK_URL){
   try{await fetch(NOTIFY_WEBHOOK_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({orderId,service:body.service,details:clean,createdAt:record.created_at})});}catch(e){console.error("Notification webhook failed",e);}
  }
  return json({ok:true,orderId});
 } catch(e){console.error(e);return json({error:"Dữ liệu gửi lên không hợp lệ"},400);}
};